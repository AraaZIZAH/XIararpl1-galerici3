<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Album_m extends CI_Model {

    public function get_all() {
        return $this->db->get('albums')->result();
    }

    public function get_by_user($user_id) {
        return $this->db->get_where('albums', ['id_user' => $user_id])->result();
    }

    public function get($id) {
        return $this->db->get_where('albums', ['id' => $id])->row();
    }

    public function insert($data) {
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        $this->db->insert('albums', $data);
    }

    public function update($id, $data) {
        $data['updated_at'] = date('Y-m-d H:i:s');
        $this->db->where('id', $id);
        $this->db->update('albums', $data);
    }

    public function delete($id) {
        $this->db->where('id', $id);
        $this->db->delete('albums');
    }
}
