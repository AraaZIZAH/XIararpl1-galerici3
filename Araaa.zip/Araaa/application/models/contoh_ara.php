<?php
 
class Contoh_Ara extends CI_Model {
  public function get_data()
{
    
}

} 

 ?>