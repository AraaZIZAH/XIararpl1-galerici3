<?php 

class ara extends CI_Model {
     public function get_data()

{

}
}


 ?>