<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Foto_m extends CI_Model {

    public function get_all() {
        $this->db->select('fotos.*, albums.nama as namaalbum');
        $this->db->from('fotos');
        $this->db->join('albums', 'albums.id = fotos.albumid', 'left');
        $this->db->where('fotos.is_deleted', 0);
        return $this->db->get()->result();
    }

    public function get_by_album($album_id) {
        $this->db->select('fotos.*, albums.nama as namaalbum');
        $this->db->from('fotos');
        $this->db->join('albums', 'albums.id = fotos.albumid', 'left');
        $this->db->where('fotos.is_deleted', 0);
        $this->db->where('fotos.albumid', $album_id);
        return $this->db->get()->result();
    }

    public function insert($data) {
        $this->db->insert('fotos', $data);
    }

    public function get($id) {
        return $this->db->get_where('fotos', ['id' => $id])->row();
    }

    public function update($id, $data) {
        $this->db->where('id', $id);
        $this->db->update('fotos', $data);
    }

    public function delete($id) {
        $this->db->where('id', $id);
        $this->db->update('fotos', ['is_deleted' => 1]);
    }

    public function get_trash() {
        $this->db->select('fotos.*, albums.nama as namaalbum');
        $this->db->from('fotos');
        $this->db->join('albums', 'albums.id = fotos.albumid', 'left');
        $this->db->where('fotos.is_deleted', 1);
        return $this->db->get()->result();
    }

    public function restore($id) {
        $this->db->where('id', $id);
        return $this->db->update('fotos', ['is_deleted' => 0]);
    }

    public function hapus_permanen($id) {
        $this->db->where('id', $id);
        return $this->db->delete('fotos');
    }
}
