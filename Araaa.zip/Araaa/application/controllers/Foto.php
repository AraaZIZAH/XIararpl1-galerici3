<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Foto extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Foto_m');
        $this->load->model('Album_m');
        $this->load->helper('text');

    }
    public function index($album_id = null) {
        if ($album_id) {
            $data['fotos'] = $this->Foto_m->get_by_album($album_id);
        } else {
            $data['fotos'] = $this->Foto_m->get_all();
        }
    
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('foto/index', $data);
        $this->load->view('layout/footer');
    
    
    }
    

    public function tambah() {
        $data['albums'] = $this->Album_m->get_all();
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('foto/tambah', $data);
        $this->load->view('layout/footer');
    }

    public function simpan() {
        $config['upload_path']   = './uploads/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['max_size']      = 2048;
        $this->load->library('upload', $config);
    
        if (! $this->upload->do_upload('file')) {
            $this->session->set_flashdata('error', $this->upload->display_errors());
            redirect('foto/tambah');
            return;
        }
    
        $upload = $this->upload->data();
        $data = [
            'albumid'     => $this->input->post('albumid'),
            'filename'    => $upload['file_name'],
            'judulfoto'   => $this->input->post('judulfoto'),
            'deskripsi'   => $this->input->post('deskripsi'),
            'is_public'   => $this->input->post('is_public'),
            'is_deleted'  => 0,
            'uploaded_at' => date('Y-m-d H:i:s')
        ];
        $this->Foto_m->insert($data);
        redirect('foto');
    }

    
    

    public function edit($id) {
        $data['foto']   = $this->Foto_m->get($id);
        $data['albums'] = $this->Album_m->get_all();
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('foto/edit', $data);
        $this->load->view('layout/footer');
    }

    public function update($id) {
        $config['upload_path']   = './uploads/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['max_size']      = 2048;
        $this->load->library('upload', $config);

        if (! empty($_FILES['file']['name'])) {
            if (! $this->upload->do_upload('file')) {
                echo $this->upload->display_errors();
                return;
            }
            $upload         = $this->upload->data();
            $data['filename'] = $upload['file_name'];
        }

        $data['albumid']   = $this->input->post('albumid');
        $data['judulfoto'] = $this->input->post('judulfoto');
        $data['deskripsi'] = $this->input->post('deskripsi');
        $data['is_public'] = $this->input->post('is_public');

        $this->Foto_m->update($id, $data);
        redirect('foto');
    }

    public function hapus($id) {
        $this->Foto_m->delete($id);
        redirect('foto');
    }

    public function tempat_sampah() {
        $data['fotos'] = $this->Foto_m->get_trash();
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('foto/tempat_sampah', $data);
        $this->load->view('layout/footer');
    }

    public function restore($id) {
        $this->Foto_m->restore($id);
        redirect('foto/tempat_sampah');
    }

    public function hapus_permanen($id) {
        $this->Foto_m->hapus_permanen($id);
        redirect('foto/tempat_sampah');
    }

    
}
