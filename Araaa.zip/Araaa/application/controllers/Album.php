<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Album extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Album_m');
        $this->load->library('session');
    }

    public function index() {
        $id_user = $this->session->userdata('id_user') ?? 0;

        $data['albums'] = $this->Album_m->get_by_user($id_user);
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('album/index', $data);
        $this->load->view('layout/footer');
    }

    public function tambah() {
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('album/tambah');
        $this->load->view('layout/footer');
    }

    public function simpan() {
        $id_user = $this->session->userdata('id_user') ?? 0;

        $data = [
            'id_user'    => $id_user,
            'nama'       => $this->input->post('nama'),
            'deskripsi'  => $this->input->post('deskripsi'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $this->Album_m->insert($data);
        redirect('album');
    }

    public function edit($id) {
        $data['album'] = $this->Album_m->get($id);
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('album/edit', $data);
        $this->load->view('layout/footer');
    }

    public function update($id) {
        $data = [
            'nama'       => $this->input->post('nama'),
            'deskripsi'  => $this->input->post('deskripsi'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $this->Album_m->update($id, $data);
        redirect('album');
    }

    public function hapus($id) {
        $this->Album_m->delete($id);
        redirect('album');
    }
}
