<?php 
class  ara extends CI_Controller {

 public function index (){
  $this->load->model('m_siswa');
   $data['siswa']= $this->m_siswa->get_data();

$this->load->view('v_siswa', $data);
}

}

 ?>