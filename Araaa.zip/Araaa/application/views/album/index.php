<?php

/** @var array $albums */ ?>
<div class="row">
  <div class="col-12">
    <h2>Daftar Album</h2>
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalTambahAlbum">Tambah Album</button>
    <div class="table-responsive">
      <table class="table table-bordered text-dark border-primary" style="background-color: rgb(146, 189, 222);">
        <thead style="background-color: rgb(43, 146, 220);" class="text-dark">
          <tr>
            <th>No</th>
            <th>Nama Album</th>
            <th>Deskripsi</th>
            <th>Tanggal Upload</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($albums)) : ?>
            <?php $no = 1;
            foreach ($albums as $album) : ?>
              <tr>
                <td><?= $no++; ?></td>
                <td><?= $album->nama; ?></td>
                <td><?= $album->deskripsi; ?></td>
                <td><?= date('d M Y H:i', strtotime($album->created_at)); ?></td>
                <td>
                  <button
                    class="btn btn-sm btn-warning"
                    data-bs-toggle="modal"
                    data-bs-target="#editModal<?= $album->id; ?>">
                    <i class="bi bi-pencil-square"></i> Edit
                  </button>
                  <a href="<?= site_url('album/hapus/' . $album->id); ?>" onclick="return confirm('Yakin?')" class="btn btn-sm btn-danger">
                    <i class="bi bi-trash"></i> Hapus
                  </a>
                  </a>
                  <a href="<?= site_url('foto/index/' . $album->id); ?>" class="btn btn-sm btn-info">Lihat Foto</a>
                </td>
                </td>
              </tr>

              <div class="modal fade" id="editModal<?= $album->id; ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $album->id; ?>" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content bg-primary text-dark rounded shadow">
                    <form action="<?= site_url('album/update/' . $album->id); ?>" method="post">
                      <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel<?= $album->id; ?>">Edit Data Album</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="mb-3">
                          <label for="nama<?= $album->id; ?>" class="form-label">Nama Album</label>
                          <input type="text" name="nama" id="nama<?= $album->id; ?>" class="form-control" value="<?= $album->nama; ?>" required>
                        </div>
                        <div class="mb-3">
                          <label for="deskripsi<?= $album->id; ?>" class="form-label">Deskripsi</label>
                          <textarea name="deskripsi" id="deskripsi<?= $album->id; ?>" class="form-control" rows="3"><?= $album->deskripsi; ?></textarea>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

            <?php endforeach; ?>
          <?php else : ?>
            <tr>
              <td colspan="4" class="text-center">Belum ada album</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>

      <!-- Modal Tambah Album -->
      <div class="modal fade" id="modalTambahAlbum" tabindex="-1" aria-labelledby="modalTambahAlbumLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content bg-primary text-dark rounded shadow">
            <form action="<?= site_url('album/simpan'); ?>" method="post">
              <div class="modal-header">
                <h5 class="modal-title" id="modalTambahAlbumLabel">Tambah Album</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
              </div>
              <div class="modal-body">
                <div class="mb-3">
                  <label for="nama" class="form-label">Nama Album</label>
                  <input type="text" name="nama" id="nama" class="form-control" required>
                </div>
                <div class="mb-3">
                  <label for="deskripsi" class="form-label">Deskripsi</label>
                  <textarea name="deskripsi" id="deskripsi" class="form-control" rows="3"></textarea>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </form>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>