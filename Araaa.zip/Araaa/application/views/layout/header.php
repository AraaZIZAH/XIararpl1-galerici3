<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>Galeri Foto</title>

  <!-- Loader -->
  <link href="<?= base_url('assets/css/pace.min.css'); ?>" rel="stylesheet"/>
  <script src="<?= base_url('assets/js/pace.min.js');?>"></script>

  <!-- Favicon -->
  <link rel="icon" href="<?= base_url('assets/images/favicon.ico'); ?>" type="image/x-icon">

  <!-- Vector CSS -->
  <link href="<?= base_url('assets/plugins/vectormap/jquery-jvectormap-2.0.2.css'); ?>" rel="stylesheet"/>

  <!-- Simplebar CSS -->
  <link href="<?= base_url('assets/plugins/simplebar/css/simplebar.css'); ?>" rel="stylesheet"/>

  <!-- Bootstrap core CSS -->
  <link href="<?= base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet"/>

  <!-- Other styles -->
  <link href="<?= base_url('assets/css/animate.css'); ?>" rel="stylesheet">
  <link href="<?= base_url('assets/css/icons.css'); ?>" rel="stylesheet">
  <link href="<?= base_url('assets/css/sidebar-menu.css'); ?>" rel="stylesheet">
  <link href="<?= base_url('assets/css/app-style.css'); ?>" rel="stylesheet">
</head>
<body class="bg-theme bg-theme1">

<!-- Start wrapper-->
<div id="wrapper">

