
<footer>
  <p class="text-center">&copy; 2025 Galeri Foto. All rights reserved.</p>
</footer>

<div class="right-sidebar">
</div>

<script src="<?= base_url('assets/js/jquery.min.js'); ?>"></script>
<script src="<?= base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script> <!-- ✅ ganti yang ini -->
<script src="<?= base_url('assets/plugins/simplebar/js/simplebar.js'); ?>"></script>
<script src="<?= base_url('assets/js/sidebar-menu.js'); ?>"></script>
<script src="<?= base_url('assets/js/app-script.js'); ?>"></script>
<script src="<?= base_url('assets/plugins/Chart.js/Chart.min.js'); ?>"></script>
<script src="<?= base_url('assets/js/index.js'); ?>"></script>

</body>
</html>
