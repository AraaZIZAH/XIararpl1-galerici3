<!DOCTYPE html>
<html>
<head>
    <title>view_ara</title>
</head>
<body>
    
     <h1>Good morning everone </h1>
     <hr>
      <p>Happy happy happy yuyuyu</p>

</body>
</html>