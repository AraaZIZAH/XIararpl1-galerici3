<h2>Edit Foto</h2>
<form method="post" action="<?= site_url('foto/update/' . $foto->id); ?>" enctype="multipart/form-data">
    <label>Album</label><br>
    <select name="albumid">
        <?php foreach ($albums as $album): ?>
            <option value="<?= $album->id ?>" <?= $album->id == $foto->albumid ? 'selected' : ''; ?>>
                <?= $album->nama ?>
            </option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Judul Foto</label><br>
    <input type="text" name="judulfoto" value="<?= $foto->judulfoto ?>" required><br><br>

    <label>Deskripsi</label><br>
    <textarea name="deskripsi"><?= $foto->deskripsi ?></textarea><br><br>

    <label>Foto (Kosongkan jika tidak ingin mengubah)</label><br>
    <input type="file" name="file"><br><br>

    <label>Publik</label><br>
    <input type="radio" name="is_public" value="1" <?= $foto->is_public == 1 ? 'checked' : ''; ?>> Ya
    <input type="radio" name="is_public" value="0" <?= $foto->is_public == 0 ? 'checked' : ''; ?>> Tidak<br><br>

    <button type="submit">Simpan</button>
</form>

<a href="<?= site_url('foto'); ?>">Kembali</a>
