
<h2>Daftar Foto</h2>
<button type="button" class="btn btn-primary mb-4" data-bs-toggle="modal" data-bs-target="#modalTambahFoto">
  Upload Foto Baru
</button>

<div class="modal fade" id="modalTambahFoto" tabindex="-1" aria-labelledby="modalTambahFotoLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content bg-primary text-dark rounded shadow">
      <div class="modal-header">
        <h5 class="modal-title" id="modalTambahFotoLabel">Tambah Foto</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <form action="<?= site_url('foto/simpan'); ?>" method="post" enctype="multipart/form-data">
        <div class="modal-body">
          <div class="mb-3">
            <label for="judul" class="form-label">Judul Foto</label>
            <input type="text" name="judulfoto" id="judul" class="form-control" required>
          </div>
          <div class="mb-3">
            <label for="deskripsi" class="form-label">Deskripsi</label>
            <textarea name="deskripsi" id="deskripsi" class="form-control" rows="3"></textarea>
          </div>
          <div class="mb-3">
            <label for="albumid" class="form-label">Album</label>
            <select name="albumid" id="albumid" class="form-select">
              <?php foreach ($this->Album_m->get_all() as $album): ?>
                <option value="<?= $album->id ?>"><?= $album->nama ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label for="file" class="form-label">File Gambar</label>
            <input type="file" name="file" id="file" class="form-control" required>
          </div>
          <div class="mb-3">
            <label for="is_public" class="form-label">Publik?</label>
            <select name="is_public" id="is_public" class="form-select">
              <option value="1">Ya</option>
              <option value="0">Tidak</option>
            </select>
          </div>
        </div>
        <div class="modal-footer border-top">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        </div>
      </form>
    </div>
  </div>
</div>

</div>
<?php if (!empty($fotos)): ?>
    <div class="row">
        <?php foreach ($fotos as $foto): ?>
            <div class="col-md-3 mb-4">
                <div class="card h-100">
                    <img src="<?= base_url('uploads/' . $foto->filename); ?>"
                        class="img-fluid"
                        alt="<?= htmlspecialchars($foto->judulfoto); ?>"
                        style="object-fit:cover; height:200px;">
                    <div class="card-body">
                    <p><strong>Album:</strong> <?= htmlspecialchars($foto->namaalbum); ?></p>
                        <h5 class="card-title"><?= htmlspecialchars($foto->judulfoto); ?></h5>
                        <p class="card-text">
                            <strong>Publik:</strong> <?= $foto->is_public ? 'Ya' : 'Tidak'; ?><br>
                            <?= word_limiter(strip_tags($foto->deskripsi), 10); ?>
                        </p>
                    </div>
                    <div class="card-footer text-center">
                        <a href="<?= site_url('foto/edit/' . $foto->id); ?>" class="btn btn-sm btn-secondary">Edit</a>
                        <a href="<?= site_url('foto/hapus/' . $foto->id); ?>"
                            class="btn btn-sm btn-danger"
                            onclick="return confirm('Yakin ingin menghapus foto ini?')">Hapus</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <div class="alert alert-info">Belum ada foto.</div>
<?php endif; ?>