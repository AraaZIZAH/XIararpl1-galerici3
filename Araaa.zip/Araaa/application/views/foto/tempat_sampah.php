<h2>Tempat Sampah Foto</h2>
<table border="1" cellpadding="5" cellspacing="0">
    <thead>
        <tr>
            <th>No</th>
            <th>Thumbnail</th>
            <th>Judul</th>
            <th>Album</th>
            <th>Deskripsi</th>
            <th>Publik</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($fotos)) : ?>
            <?php $no = 1; foreach ($fotos as $foto) : ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><img src="<?= base_url('uploads/' . $foto->filename); ?>" width="100"></td>
                    <td><?= $foto->judulfoto; ?></td>
                    <td><?= $foto->namaalbum; ?></td>
                    <td><?= $foto->deskripsi; ?></td>
                    <td><?= $foto->is_public ? 'Ya' : 'Tidak'; ?></td>
                    <td>
                        <a href="<?= site_url('foto/restore/' . $foto->id); ?>" class="btn btn-success">Restore</a> 
                        | 
                        <a href="<?= site_url('foto/hapus_permanen/' . $foto->id); ?>" class="btn btn-danger" onclick="return confirm('Hapus foto ini secara permanen?')">Hapus Permanen</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else : ?>
            <tr><td colspan="7">Tidak ada foto yang dihapus.</td></tr>
        <?php endif; ?>
    </tbody>
</table>
