

<html>
<head>
  <title>Bio Data Diri</title>
</head>
<body>

 <table border="1px solid black">
  
     <tr>
        <th>Nama</th>
        <th>Kelas</th>
        <th>Ttl</th>
        <th>Jurusan</th>
        <th>Jenis Kelamin</th>
        <th>Alamat</th>
        <th>Email</th>
        <th>Instagram</th>
    </tr>

     <?php foreach ($siswa as $siswa) :?>
   
   <tr>
   
     <td><?php echo $siswa['nama_lengkap']; ?></td>
     <td><?php echo $siswa['kelas']; ?></td>
     <td><?php echo $siswa['ttl']; ?></td>

     <td><?php echo $siswa['jurusan']; ?></td>
     <td><?php echo $siswa['jenis_kelamin']; ?></td>
     <td><?php echo $siswa['alamat']; ?></td>
     <td><?php echo $siswa['email']; ?></td>
     <td><?php echo $siswa['instagram']; ?></td>




  <?php endforeach; ?>



   </tr>     
    

</table>

</body>
</html>